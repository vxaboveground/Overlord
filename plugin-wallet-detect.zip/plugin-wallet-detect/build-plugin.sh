#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_DIR="${ROOT_DIR}"
NATIVE_DIR="${PLUGIN_DIR}/native"
PLUGIN_NAME="wallet-detect"
ZIP_OUT="${PLUGIN_DIR}/${PLUGIN_NAME}.zip"

if [[ ! -d "${NATIVE_DIR}" ]]; then
  echo "[error] native folder not found: ${NATIVE_DIR}" >&2
  exit 1
fi

pushd "${NATIVE_DIR}" >/dev/null

# Detect current OS/arch for default build
HOST_OS="$(go env GOOS)"
HOST_ARCH="$(go env GOARCH)"

# Build matrix - build for all major platforms
DEFAULT_TARGETS="windows-amd64 windows-386 linux-amd64 linux-arm64 darwin-arm64 darwin-amd64"
BUILD_TARGETS="${BUILD_TARGETS:-${DEFAULT_TARGETS}}"

BUILT_FILES=()

for target in ${BUILD_TARGETS}; do
  os="${target%%-*}"
  arch="${target#*-}"

  if [[ "${os}" == "windows" ]]; then
    ext="dll"
  elif [[ "${os}" == "darwin" ]]; then
    ext="dylib"
  else
    ext="so"
  fi
  buildmode="c-shared"

  outfile="${PLUGIN_DIR}/${PLUGIN_NAME}-${os}-${arch}.${ext}"
  echo "[build] GOOS=${os} GOARCH=${arch} CGO_ENABLED=1 go build -buildmode=${buildmode} -o ${outfile}"
  CGO_ENABLED=1 GOOS="${os}" GOARCH="${arch}" go build -buildmode="${buildmode}" -o "${outfile}" .
  BUILT_FILES+=("${PLUGIN_NAME}-${os}-${arch}.${ext}")
done

popd >/dev/null

rm -f "${ZIP_OUT}"

# Collect files to zip
ZIP_FILES=()
for bf in "${BUILT_FILES[@]}"; do
  ZIP_FILES+=("${bf}")
done
# Add web assets
for asset in "${PLUGIN_NAME}.html" "${PLUGIN_NAME}.css" "${PLUGIN_NAME}.js"; do
  if [[ -f "${PLUGIN_DIR}/${asset}" ]]; then
    ZIP_FILES+=("${asset}")
  fi
done

if command -v zip >/dev/null 2>&1; then
  (cd "${PLUGIN_DIR}" && zip -q "${ZIP_OUT}" "${ZIP_FILES[@]}")
else
  echo "[error] zip not found. Please install zip." >&2
  exit 1
fi

echo ""
echo "[ok] ${ZIP_OUT}"
echo ""
echo "Next steps:"
echo "1. Upload ${PLUGIN_NAME}.zip to Overlord at /plugins"
echo "2. Enable auto-load in plugin settings"
echo "3. Configure auto-start events (optional)"
echo ""
