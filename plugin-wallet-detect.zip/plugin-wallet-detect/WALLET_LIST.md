# Complete Wallet Detection List

This plugin detects **70+ cryptocurrency wallets** across Windows, Linux, and macOS.

## Browser Extensions (40+)

### Popular Wallets
1. **MetaMask** 🦊 - Most popular Ethereum wallet
2. **Phantom** 👻 - Leading Solana wallet
3. **Binance Wallet** 🟡 - Binance Chain extension
4. **Coinbase Wallet** 🔵 - Coinbase's self-custody wallet
5. **Trust Wallet** 🛡️ - Multi-chain mobile & extension
6. **Brave Wallet** 🦁 - Built into Brave browser
7. **Exodus** 🚀 - Multi-currency extension
8. **Rabby** 🐰 - DeFi-focused wallet

### Exchange Wallets
9. **OKX Wallet** ⭕ - OKX exchange wallet
10. **Binance Wallet** 🟡 - Binance extension
11. **Crypto.com Wallet** 💳 - Crypto.com extension

### DeFi & Gaming
12. **Ronin Wallet** ⚔️ - Axie Infinity ecosystem
13. **Wombat** 🐨 - Gaming wallet
14. **Guild** 🏰 - Gaming guilds

### Multi-Chain Wallets
15. **Math Wallet** 🔢 - Multi-chain support
16. **TokenPocket** 🪙 - 30+ blockchains
17. **SafePal** 🔐 - Hardware + software
18. **Coin98** 💯 - Multi-chain DeFi
19. **Clover** 🍀 - Polkadot ecosystem
20. **BitKeep** 🔑 - DeFi aggregator

### Blockchain-Specific
21. **TronLink** 🔺 - Tron network
22. **Keplr** 🌌 - Cosmos ecosystem
23. **Terra Station** 🌍 - Terra Luna
24. **NeoLine** 🔷 - Neo blockchain
25. **ioPay** 💰 - IoTeX network
26. **Nami** 🌊 - Cardano wallet
27. **Eternl** ♾️ - Cardano wallet
28. **Petra Aptos** 🪨 - Aptos blockchain

### Solana Ecosystem
29. **Phantom** 👻 - Primary Solana wallet
30. **Solflare** ☀️ - Solana ecosystem
31. **Slope** 📈 - Solana mobile wallet

### Advanced/Privacy
32. **XDEFI Wallet** ❌ - Cross-chain DeFi
33. **Liquality** 💧 - Atomic swaps
34. **Talisman** 🧿 - Polkadot/Kusama
35. **Polymesh** 🔗 - Security tokens
36. **Saturn** 🪐 - Layer 2 focused

### Classic Wallets
37. **Jaxx Liberty** 💎 - Multi-currency veteran
38. **Guarda** 🛡️ - 50+ blockchains
39. **Edge Wallet** 🔷 - Privacy-focused
40. **Core** 🌀 - Avalanche ecosystem

## Desktop Applications (30+)

### Popular Desktop Wallets
1. **Exodus Desktop** 🚀 - Beautiful UI, multi-currency
2. **Electrum** ⚡ - Bitcoin-focused, lightweight
3. **Atomic Wallet** ⚛️ - 300+ cryptocurrencies
4. **Bitcoin Core** ₿ - Official Bitcoin client
5. **Ethereum Wallet** Ξ - Official Ethereum client

### Hardware Wallet Software
6. **Ledger Live** 🔐 - Ledger hardware companion
7. **Trezor Suite** 🔒 - Trezor hardware companion

### Exchange Desktop Apps
8. **Binance Desktop** 🟡 - Binance wallet app
9. **Trust Wallet Desktop** 🛡️ - Trust desktop version

### Multi-Currency Wallets
10. **Coinomi** 🪙 - 1,770+ assets
11. **Jaxx Liberty Desktop** 💎 - Multi-platform sync
12. **Guarda Desktop** 🛡️ - 50+ blockchains
13. **Edge Wallet** 🔷 - Mobile + desktop sync

### Privacy-Focused
14. **Monero GUI** Ɱ - Official Monero wallet
15. **Wasabi Wallet** 🥷 - Bitcoin privacy (CoinJoin)
16. **Samourai Wallet** 🥷 - Bitcoin privacy
17. **Sparrow Wallet** 🐦 - Bitcoin privacy & multisig
18. **Specter Desktop** 👻 - Bitcoin multisig

### Cryptocurrency-Specific
19. **Zcash** 🔒 - Privacy coin wallet
20. **Dash Core** 💨 - Dash official wallet
21. **Litecoin Core** Ł - Litecoin official wallet
22. **Dogecoin Core** 🐕 - Dogecoin official wallet

### Cardano Ecosystem
23. **Daedalus** 🏛️ - Official Cardano wallet
24. **Yoroi** 🌸 - Light Cardano wallet

### Lightning Network
25. **Zap Wallet** ⚡ - Bitcoin Lightning
26. **Phoenix Wallet** 🔥 - Lightning wallet
27. **Breez Wallet** 🌬️ - Lightning network
28. **BlueWallet** 💙 - Bitcoin + Lightning

### Advanced/Legacy
29. **MultiBit** 💼 - Classic Bitcoin wallet
30. **Armory** 🛡️ - Cold storage specialist
31. **Bitcoin Knots** 🪢 - Bitcoin Core variant
32. **Mycelium** 🍄 - Bitcoin mobile pioneer
33. **Blockchain.com Desktop** ⛓️ - Blockchain.com app

## Detection Methods

### Browser Extensions
- **Chrome/Edge**: `%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\{extension-id}`
- **Firefox**: `%APPDATA%\Mozilla\Firefox\Profiles\{profile}\extensions`
- **Brave**: `%LOCALAPPDATA%\BraveSoftware\Brave-Browser\User Data\Default\Extensions`

### Desktop Applications
- **Windows**: `%APPDATA%\{WalletName}` or `%LOCALAPPDATA%\{WalletName}`
- **Linux**: `~/.config/{WalletName}` or `~/.{walletname}`
- **macOS**: `~/Library/Application Support/{WalletName}`

## Coverage by Platform

| Platform | Browser Extensions | Desktop Apps | Total |
|----------|-------------------|--------------|-------|
| Windows  | 40+               | 33+          | 73+   |
| Linux    | 17+               | 23+          | 40+   |
| macOS    | 17+               | 23+          | 40+   |

## Adding Custom Wallets

To add a new wallet, edit `native/main.go` and add to the appropriate scanner:

```go
// For browser extensions
"NewWallet": {
    filepath.Join(localAppData, "Google\\Chrome\\User Data\\Default\\Extensions\\{extension-id}"),
},

// For desktop apps
"NewDesktopWallet": {
    filepath.Join(appData, "NewDesktopWallet"),
},
```

Don't forget to add the icon in `wallet-detect.js`:

```javascript
"NewWallet": "🆕",
```

## Popular Extension IDs

Here are the Chrome extension IDs for manual verification:

- MetaMask: `nkbihfbeogaeaoehlefnkodbefgpgknn`
- Phantom: `bfnaelmomeimhlpmgjnjophhpkkoljpa`
- Binance Wallet: `fhbohimaelbohpjbbldcngcnapndodjp`
- Coinbase Wallet: `hnfanknocfeofbddgcijnmhnfnkdnaad`
- Trust Wallet: `egjidjbpglichdcondbcbdnbeeppgdph`
- OKX Wallet: `mcohilncbfahbmgdjkbpemcciiolgcge`
- Rabby: `acmacodkjbdgmoleebolmdjonilkdbch`
- Exodus: `aholpfdialjgjfhomihkjbmgjidlcdno`

## Notes

- Detection checks for **folder existence only** (no file access)
- Browser extensions must be in **default profile**
- Desktop apps must use **standard installation paths**
- Custom installation paths may not be detected
- Portable/USB wallet installations may be missed

## Future Additions

Consider adding:
- Backpack (Solana)
- Glow (Solana)
- Suiet (Sui)
- Martian (Aptos)
- Pontem (Aptos)
- Hiro Wallet (Stacks)
- XDC Pay (XinFin)
- Keeper (Waves)
- Temple (Tezos)

To request a wallet addition, create an issue with:
1. Wallet name
2. Official website
3. Installation paths (Windows/Linux/macOS)
4. Chrome extension ID (if applicable)
