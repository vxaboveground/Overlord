module wallet-detect-plugin

go 1.24
