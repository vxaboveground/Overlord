#!/usr/bin/env bash
# Wallet Path Verification Script
# Use this to verify wallet detection paths on your system

echo "=== Crypto Wallet Path Verification ==="
echo ""

# Detect OS
if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    OS="windows"
    LOCALAPPDATA="$LOCALAPPDATA"
    APPDATA="$APPDATA"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
    HOME="$HOME"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
    HOME="$HOME"
else
    echo "Unknown OS: $OSTYPE"
    exit 1
fi

echo "Detected OS: $OS"
echo ""

# Function to check if path exists
check_path() {
    local name="$1"
    local path="$2"
    if [ -d "$path" ]; then
        echo "✅ FOUND: $name"
        echo "   Path: $path"
    else
        echo "❌ NOT FOUND: $name"
        echo "   Expected: $path"
    fi
}

if [ "$OS" == "windows" ]; then
    echo "=== Browser Extensions (Chrome) ==="
    check_path "MetaMask" "$LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Extensions\\nkbihfbeogaeaoehlefnkodbefgpgknn"
    check_path "Phantom" "$LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Extensions\\bfnaelmomeimhlpmgjnjophhpkkoljpa"
    check_path "Binance Wallet" "$LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Extensions\\fhbohimaelbohpjbbldcngcnapndodjp"
    check_path "Coinbase Wallet" "$LOCALAPPDATA\\Google\\Chrome\\User Data\\Default\\Extensions\\hnfanknocfeofbddgcijnmhnfnkdnaad"
    
    echo ""
    echo "=== Desktop Wallets ==="
    check_path "Exodus" "$APPDATA\\Exodus"
    check_path "Electrum" "$APPDATA\\Electrum"
    check_path "Atomic Wallet" "$APPDATA\\atomic"
    check_path "Bitcoin Core" "$APPDATA\\Bitcoin"
    check_path "Ledger Live" "$APPDATA\\Ledger Live"

elif [ "$OS" == "linux" ]; then
    echo "=== Browser Extensions (Chrome) ==="
    check_path "MetaMask" "$HOME/.config/google-chrome/Default/Extensions/nkbihfbeogaeaoehlefnkodbefgpgknn"
    check_path "Phantom" "$HOME/.config/google-chrome/Default/Extensions/bfnaelmomeimhlpmgjnjophhpkkoljpa"
    check_path "Binance Wallet" "$HOME/.config/google-chrome/Default/Extensions/fhbohimaelbohpjbbldcngcnapndodjp"
    
    echo ""
    echo "=== Desktop Wallets ==="
    check_path "Exodus" "$HOME/.config/Exodus"
    check_path "Electrum" "$HOME/.electrum"
    check_path "Atomic Wallet" "$HOME/.atomic"
    check_path "Bitcoin Core" "$HOME/.bitcoin"

elif [ "$OS" == "macos" ]; then
    echo "=== Browser Extensions (Chrome) ==="
    check_path "MetaMask" "$HOME/Library/Application Support/Google/Chrome/Default/Extensions/nkbihfbeogaeaoehlefnkodbefgpgknn"
    check_path "Phantom" "$HOME/Library/Application Support/Google/Chrome/Default/Extensions/bfnaelmomeimhlpmgjnjophhpkkoljpa"
    
    echo ""
    echo "=== Desktop Wallets ==="
    check_path "Exodus" "$HOME/Library/Application Support/Exodus"
    check_path "Electrum" "$HOME/.electrum"
    check_path "Atomic Wallet" "$HOME/Library/Application Support/atomic"
    check_path "Bitcoin Core" "$HOME/Library/Application Support/Bitcoin"
fi

echo ""
echo "=== Manual Verification ==="
echo "To manually check Chrome extensions on this system:"
if [ "$OS" == "windows" ]; then
    echo "  dir \"%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Extensions\""
elif [ "$OS" == "linux" ]; then
    echo "  ls ~/.config/google-chrome/Default/Extensions/"
elif [ "$OS" == "macos" ]; then
    echo "  ls ~/Library/Application\ Support/Google/Chrome/Default/Extensions/"
fi
